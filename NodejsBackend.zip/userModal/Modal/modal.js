import mongoose from 'mongoose';

// saving user's personal Details as an embedded document 
const personalDetailsSchema = new mongoose.Schema({
  firstName: { 
    type: String, 
    required: false },

  lastName: { 
    type: String, 
    required: false },

  phoneNo: 
  { type: String, 
    required: false },

  photo: { 
    type: String, 
    required: false },

  cv: { 
    type: String, 
    required: false },

  links: [{ 
    type: String, 
    required: false }],

  gender: { 
    type: String, 
    required: false },

  city: { 
    type: String, 
    required: false },

  languages: { 
    type: String, 
    required: false },

}, { _id: false }); 

const educationalDetailsSchema = new mongoose.Schema({
  type: { 
    type: String, 
    enum: ['graduation', 'post-graduation', 'secondary', 'senior-secondary', 'certification'], 
    required: true 
  },
  degree: { 
    type: String, 
    required: true },

  institution: { 
    type: String, 
    required: true },

  passingYear: { 
    type: String, 
    required: true },

  grade: { 
    type: String, 
    required: false },

  fieldOfStudy: { 
    type: String, 
    required: false },

}, { _id: false });

const careerObjectiveSchema = new mongoose.Schema({
  type: String,
}, { timestamps: true });


const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  userType: {
    type: String,
    enum: ['candidate', 'company', 'HiringManager', 'administration', 'superadmin', 'platformSuperHR', 'platformJrHr', 'other'],
    required: true
  },
  addedBy: {
    type: mongoose.Schema.Types.ObjectId, ref: 'User'
  },
  isVerified: {
    type: Boolean,
    default: false
  },

  // Personal details fields for candidates
  personalDetails: personalDetailsSchema,
  // Educational details array for candidates
  educationalDetails: [educationalDetailsSchema],
  // CareerObjective details for candidates
  careerObjective: { type: String },
  // Company profile fields
  phoneNo: {
    type: String,
    required: false
  },
  location: {
    streetAddress: {
      type: String,
      required: false
    },
    city: {
      type: String,
      required: false
    },
    state: {
      type: String,
      required: false
    },
    zipCode: {
      type: String,
      required: false
    },
  },
  websiteUrl: {
    type: String,
    required: false
  },
  industryType: {
    type: String,
    required: false
  },
  companySize: {
    type: String,
    required: false
  },
  representative: {
    name: {
      type: String,
      required: false
    },
    position: {
      type: String,
      required: false
    }
  },
  registrationNumber: {
    type: String,
    required: false
  },
  gstNumber: {
    type: String,
    required: false
  },

}, { timestamps: true });

export default mongoose.model('User', userSchema);
